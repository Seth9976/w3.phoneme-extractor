#!/bin/bash
git clone --depth 1 --branch=v5.0.3 https://github.com/cmusphinx/pocketsphinx.git
